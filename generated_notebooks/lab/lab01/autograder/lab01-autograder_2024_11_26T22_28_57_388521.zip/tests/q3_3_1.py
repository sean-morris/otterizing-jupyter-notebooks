OK_FORMAT = True

test = {   'name': 'q3_3_1',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> time != ...\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> round(time, 5)\n1.2', 'hidden': False, 'locked': False},
                                   {'code': '>>> estimated_distance_m != ...\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> estimated_distance_m != 113\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> round(estimated_distance_m, 5)\n1.13', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
