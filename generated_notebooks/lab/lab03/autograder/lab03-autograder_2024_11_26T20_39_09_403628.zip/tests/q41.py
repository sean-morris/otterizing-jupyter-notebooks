OK_FORMAT = True

test = {   'name': 'q41',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> import numpy as np\n>>> type(year_population_crossed_6_billion) == int or type(year_population_crossed_6_billion) == np.int64\nTrue',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': '>>> year_population_crossed_6_billion == 1999\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
