OK_FORMAT = True

test = {   'name': 'q42',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> abs(before_2000 - 8.278362573099415) < 1e-05\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> abs(after_or_in_2000 - 8.237974683544303) < 1e-05\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
