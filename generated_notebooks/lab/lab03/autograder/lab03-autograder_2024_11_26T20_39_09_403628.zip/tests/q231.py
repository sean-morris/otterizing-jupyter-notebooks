OK_FORMAT = True

test = {   'name': 'q231',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> import numpy as np\n>>> type(population_rounded) == np.ndarray\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> import numpy as np\n>>> sum(population_rounded) == 312868000000\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
