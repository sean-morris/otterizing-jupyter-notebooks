OK_FORMAT = True

test = {   'name': 'q4_1_1',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> num_avenues_away != ...\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> num_avenues_away != -3\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> num_avenues_away\n3', 'hidden': False, 'locked': False},
                                   {'code': '>>> manhattan_distance\n1462', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
