OK_FORMAT = True

test = {   'name': 'q3_1_2',
    'points': None,
    'suites': [   {   'cases': [   {'code': ">>> 'seconds_in_a_decade' in vars()\nTrue", 'hidden': False, 'locked': False},
                                   {'code': '>>> seconds_in_a_decade != ...\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> seconds_in_a_decade != 315360000\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> seconds_in_a_decade == 315532800\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
