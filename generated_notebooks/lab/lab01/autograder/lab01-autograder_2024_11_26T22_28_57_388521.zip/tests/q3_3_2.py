OK_FORMAT = True

test = {   'name': 'q3_3_2',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> predicted_distance_m != ...\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> round(predicted_distance_m, 5)\n1.17022', 'hidden': False, 'locked': False},
                                   {'code': '>>> round(difference, 5)\n0.04022', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
